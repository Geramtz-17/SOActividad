package com.example.apartamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
